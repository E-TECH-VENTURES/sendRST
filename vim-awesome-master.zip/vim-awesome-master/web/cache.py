"""Module to hold the instance of the cache"""

from flask.ext.cache import Cache


cache = Cache()
