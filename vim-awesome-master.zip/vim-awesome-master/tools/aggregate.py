import db.tags


if __name__ == '__main__':
    db.tags.aggregate_tags()
