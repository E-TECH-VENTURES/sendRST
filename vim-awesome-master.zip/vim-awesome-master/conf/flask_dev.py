ENV = 'dev'

CACHE_TYPE = 'simple'
