sendRST
=======

simple script to send RST (or FIN) packets to db.currentOP() results, to hopefully close all connections to a mongod
